<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contact</h3>
						<div class="widget-body">
						 		<p>Tél : +243 998 587 876 | +243 816915864<br>
								<a href="mailto:insnordkivu@yahoo.fr"> insnordkivu@yahoo.fr</a><br>
								<a href="http://www.ins-nordkivu.org">www.ins-nordkivu.org</a> <br>
								<br>
								134 bis, Av. du Port, Quartier Les Volcans, Commune de Goma, Voir Ancien Auditorat Militaire, avec la Division Provinciale du Plan, Ville de Goma/RDC
							</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Suivez-vous</h3>
						<div class="widget-body">
							<p class="follow-me-icons clearfix">
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-youtube"></i></a>
								<a href="#"><i class="fa fa-google-plus"></i></a>
								<a href="#"><i class="fa fa-facebook"></i></a>
							</p>	
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Autres</h3>
						<div class="widget-body">
							<p><a href="http://www.ins-nordkivu.org/generales/page_terms.php">Termes et conditions</a></p>
							<p><a class="footer-brand" href="http://www.ins-nordkivu.org/index.php"><img src="http://www.ins-nordkivu.org/assets/img/logo.jpg" alt="Ins"></a></p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					
					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="simplenav">
							<a href="http://www.ins-nordkivu.org/index.php">Accueil</a> | 
							<a href="http://www.ins-nordkivu.org/generales/mission.php"> mission</a>|
							<a href="http://www.ins-nordkivu.org/generales/publications.php">Publications</a> |
							<a href="http://www.ins-nordkivu.org/generales/contact.php">contacter</a> |
								<b><a href="http://www.ins-nordkivu.org/generales/signin.php">Connexion</a></b>
							</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Copyright &copy;  Copyrigth 2019 | Institut National de la Statistique – Tous droits réservés <a href="http://www.davtech-achat.com" rel="davtech">davtech soft</a> 
							</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		

  <!-- JavaScript libs are placed at the end of the document so the pages load faster -->
  <script src="https://unpkg.com/leaflet@1.4.0/dist/leaflet.js"
   integrity="sha512-QVftwZFqvtRNi0ZyCtsznlKSWOStnDORoefr1enyq5mVL4tmKB3S/EnC3rRJcxCPavG10IcrVGSmPh6Qw5lwrg=="
   crossorigin=""></script>
   <script src="http://www.ins-nordkivu.org/assets/js/vendor.js"></script>
   <script src="http://maps.stamen.com/js/tile.stamen.js"></script>
	<script src="http://www.ins-nordkivu.org/assets/js/jquery.min.js"></script>
	<script src="http://www.ins-nordkivu.org/assets/js/jquery-3.3.1.js"></script>
	<script src="http://www.ins-nordkivu.org/assets/js/bootstrap.min.js"></script>
	<script src="http://www.ins-nordkivu.org/assets/js/headroom.min.js"></script>
	<script src="http://www.ins-nordkivu.org/assets/js/jQuery.headroom.min.js"></script>
	<script src="http://www.ins-nordkivu.org/assets/js/template.js"></script>
	<script src="http://www.ins-nordkivu.org/assets/js/main.js"></script>




</body>

</html>
