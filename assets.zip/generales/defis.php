
<?php

include("../header.php");

?>
<div class="container">

<ol class="breadcrumb">
<li><a href="http://localshost/ins-nordkivu/index.php">Accueil</a></li>
<li class="active">Nos défis</li>
</ol>

<div class="row">

<!-- Article main content -->
<article class="col-sm-8 maincontent">
	<header class="page-header">
	<h3>Nos défis</h3>
	</header>
			<p>La dotation du Système Statistique National d’un cadre réglementaire et institutionnel efficace pour une meilleure coordination des activités</p>

		<p>Le renforcement du pouvoir de l’INS en matière de coordination du Système Statistique Provincial </p>

		<p>La dotation du système statistique Provincial des ressources nécessaires à son fonctionnement</p>

		<p>Le renforcement de capacités en ressources humaines, financières et matérielles pour la production statistique provinciale</p>

		<p>L’amélioration des capacités de stockage, d’archivage et de diffusion de données par l’utilisation des NTIC</p>

		<p>La motivation des producteurs des statistiques à la base et l’amélioration du système de transmission sécurisées et rapide de données.</p>

		</article>

<?php
		   include("../siderbar.php");
 ?>

</div>
</div>


<?php
		   include("../footer.php");
 ?>
