
<?php

include("../header.php");

?>
<div class="container">

<ol class="breadcrumb">
<li><a href="http://www.ins-nordkivu.org/index.php">Accueil</a></li>
<li class="active">Les indices de prix</li>
</ol>

<div class="row">

<!-- Article main content -->
<article class="col-sm-8 maincontent">
	<header class="page-header">
	<h3>Les indices de prix</h3>
	</header>
	<p><img src="http://www.ins-nordkivu.org/assets/img/publication/marche.gif" alt="" class="img-rounded pull-right" width="300" >
					
					
					</p>
						</article>

<?php
		   include("../siderbar.php");
 ?>

</div>
</div>


<?php
		   include("../footer.php");
 ?>
