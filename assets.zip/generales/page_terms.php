
<?php
	include("../header.php");
?>

<div class="container">

<div class="row">

			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header style="text-align:center;" class="page-header">
					<h3  >Termes et conditions</h3>
				</header>
				
				
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	
	<?php
            include("../footer.php");
  ?>