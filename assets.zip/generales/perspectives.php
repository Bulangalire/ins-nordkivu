
<?php

include("../header.php");

?>
<div class="container">

<ol class="breadcrumb">
<li><a href="http://www.ins-nordkivu.org/index.php">Accueil</a></li>
<li class="active">Nos perspectives</li>
</ol>

<div class="row">

<!-- Article main content -->
<article class="col-sm-8 maincontent">
	<header class="page-header">
	<h3>Nos perspectives</h3>
	</header>
						
						<ul>
						    <li> Vulgariser le décret portant organisation et fonctionnement du Système Statistique National.</li>
							<li> Renforcer le plaidoyer en faveur de la statistique</li>
							<li> Créer et rendre fonctionnel des services statistiques provinciaux au niveau des Villes, Communes, Territoires et cités par la création des Antennes Statistiques Locales. </li>
							<li> Harmoniser les outils de collecte</li>
							<li>Renforcer la culture statistique</li>
							
						</ul>
						</article>

<?php
		   include("../siderbar.php");
 ?>

</div>
</div>


<?php
		   include("../footer.php");
 ?>
