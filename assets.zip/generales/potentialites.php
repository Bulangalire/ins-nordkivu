
<?php

include("../header.php");

?>
<div class="container">

<ol class="breadcrumb">
<li><a href="http://www.ins-nordkivu.org/index.php">Accueil</a></li>
<li class="active">Nos potentialités </li>
</ol>

<div class="row">

<!-- Article main content -->
<article class="col-sm-8 maincontent">
	<header class="page-header">
	<h3>Nos potentialités </h3>
	</header>
					
						<p> L’INS dispose <a href="http://www.ins-nordkivu.org/generales/equipe.php" >d’un personnel </a> multisectoriel actif et spécialisé dans différents domaines (statistique, démographie, économie, informatique, gestion, finance etc.) ;</p>
						
						<p  style="text-align: justify; padding-right :4px;" >Les membres de son personnel ont soit coordonné, soit participé à la préparation et exécution des différentes <a href="http://www.ins-nordkivu.org/generales/enquetes.php" > enquêtes sociodémographiques et économiques</a>, des enquêtes Connaissances Attitudes et Pratiques dans différents domaines de la vie sociale, à toutes les étapes en allant de la préparation des protocoles jusqu’à la production des rapports en passant par la formation de l’équipe d’enquête, l’encodage, la fiabilisation de données, leur traitement, l’analyse et la publication. Ils ont participé à des études de base, de suivi et évaluation des projets
									
						 <img style="float:left; padding: 5px;" src="http://www.ins-nordkivu.org/assets/img/publication/evolutionManioc_2010-2016.jpg" height="100%" alt="manioc" width="100%">
						 </p>
						<p> 
						 Un bâtiment propre est déjà disponible et très bientôt un Centre de calcul sera fonctionnel.
						 <br />
						 <img style="float:left; padding: 5px;" src="http://www.ins-nordkivu.org/assets/img/publication/entree.jpg" height="100%" alt="manioc" width="100%">
						
						  </p>
					
						  </article>

<?php
		   include("../siderbar.php");
 ?>

</div>
</div>


<?php
		   include("../footer.php");
 ?>
