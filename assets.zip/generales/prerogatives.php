
<?php

include("../header.php");

?>
<div class="container">

<ol class="breadcrumb">
<li><a href="http://www.ins-nordkivu.org/index.php">Accueil</a></li>
<li class="active">Nos prérogatives</li>
</ol>

<div class="row">

<!-- Article main content -->
<article class="col-sm-8 maincontent">
	<header class="page-header">
	<h3>Nos prérogatives</h3>
	</header>
						
						<p> Les textes règlementaires sur l’organisation et le fonctionnement du Système Statistique National explicitent les domaines d’intervention de l’INS : </p> <br />
						<p> Les statistiques et les recensements d’intérêt national sont des matières de la compétence exclusive du Gouvernement Central et se font sous la responsabilité scientifique et technique de l’INS ;</p>
						<p> Toute enquête statistique des services publics est soumise au visa préalable de l’INS ;</p>
							<p> Le décret n°10/05 demande aux services statistiques sectoriels de travailler en collaboration étroite avec l’INS et de lui transmettre les copies de leurs produits.</p>
							</article>

<?php
		   include("../siderbar.php");
 ?>

</div>
</div>


<?php
		   include("../footer.php");
 ?>
