
<?php

	include("../../header.php");

?>
<div class="container">

<ol class="breadcrumb">
	<li><a href="http://www.ins-nordkivu.org/index.php">Accueil</a></li>
	<li class="active">Ateliers</li>
</ol>

<div class="row">
	
	<!-- Article main content -->
	<article class="col-sm-8 maincontent">
		<header class="page-header">
		<h3>Ateliers</h3>
		</header>
	
		

	 </article>



 <?php
            include("../../siderbar.php");
  ?>

</div>
</div>


 <?php
            include("../../footer.php");
  ?>
