
<?php

	include("../../header.php");

?>
<div class="container">

<ol class="breadcrumb">
	<li><a href="http://www.ins-nordkivu.org/index.php">Accueil</a></li>
	<li class="active">Statistiques démographie </li>
</ol>

<div class="row">
	
	<!-- Article main content -->
	<article class="col-sm-8 maincontent">
		<header class="page-header">
		<h3>Statistiques démographie </h3>
		</header>
		<h4>Population congolaise, étrangère non refugiée et étrangère refugiée par groupe d’âge et sexe, Ville de Goma, 2013</h4>
	
		<a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title=""
					                   data-image="http://www.ins-nordkivu.org/assets/img/publication/demographie_goma_2013.jpg?cs=srgb&dl=aerial-bridge-buildings-50631.jpg&fm=jpg"
					                   data-target="#image-gallery">
					                    <img class="img-thumbnail"
					                         src="http://www.ins-nordkivu.org/assets/img/publication/demographie_goma_2013.jpg?cs=srgb&dl=aerial-bridge-buildings-50631.jpg&fm=jpg"
					                         alt="Retratos">
					                </a>
	 
	
	<br>
	<br>
	<a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title=""
					                   data-image="http://www.ins-nordkivu.org/assets/img/publication/pyramide_goma_2013.jpg?cs=srgb&dl=aerial-bridge-buildings-50631.jpg&fm=jpg"
					                   data-target="#image-gallery">
					                    <img class="img-thumbnail"
					                         src="http://www.ins-nordkivu.org/assets/img/publication/pyramide_goma_2013.jpg?cs=srgb&dl=aerial-bridge-buildings-50631.jpg&fm=jpg"
					                         alt="Retratos">
					                </a>
	 

									 
	<br>
	<br>
	<h4>Evolution de la population Congolaise par quartier commune de KARISIMBI de 2010 à 2013 </h4>	
	<a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title=""
					                   data-image="http://www.ins-nordkivu.org/assets/img/publication/comm_karisimbi_evolution_2010-2013.jpg?cs=srgb&dl=aerial-bridge-buildings-50631.jpg&fm=jpg"
					                   data-target="#image-gallery">
					                    <img class="img-thumbnail"
					                         src="http://www.ins-nordkivu.org/assets/img/publication/comm_karisimbi_evolution_2010-2013.jpg?cs=srgb&dl=aerial-bridge-buildings-50631.jpg&fm=jpg"
					                         alt="Retratos">
					                </a>
	

									<br>
	<br>
	<h4>Evolution de la population Congolaise par quartier commune de Goma de 2010 à 2013 </h4>	
	<a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title=""
					                   data-image="http://www.ins-nordkivu.org/assets/img/publication/comm_goma_evolution_2010-2013.jpg?cs=srgb&dl=aerial-bridge-buildings-50631.jpg&fm=jpg"
					                   data-target="#image-gallery">
					                    <img class="img-thumbnail"
					                         src="http://www.ins-nordkivu.org/assets/img/publication/comm_goma_evolution_2010-2013.jpg?cs=srgb&dl=aerial-bridge-buildings-50631.jpg&fm=jpg"
					                         alt="Retratos">
					                </a>
	 </article>



 <?php
            include("../../siderbar.php");
  ?>

</div>
</div>


 <?php
            include("../../footer.php");
  ?>
