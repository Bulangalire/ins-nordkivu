
<?php

include("../header.php");

?>
<div class="container">
<ol class="breadcrumb">
	<li><a href="http://www.ins-nordkivu.org/index.php">Accueil</a></li>
	<li class="active">Notre vision</li>
</ol>


<div class="row">

<!-- Article main content -->
<article class="col-sm-8 maincontent">
	<header class="page-header">
	<h3>Notre vision</h3>
	</header>

						<p><img src="http://www.ins-nordkivu.org/assets/img/publication/vision.jpg" alt="" class="img-rounded pull-right" width="300" >Notre vision est de mettre en place en province un Système Statistique National intégré et coordonné,
						 répondant à tous les besoins récurrents et émergents des utilisateurs des statistiques par
						  la fourniture des données statistiques de qualité, 
						  désagrégées et accessibles en temps réel au niveau Provincial et National.</p>
					
						</article>

<?php
		   include("../siderbar.php");
 ?>

</div>
</div>


<?php
		   include("../footer.php");
 ?>
