<!DOCTYPE html>
<html>
<head>
	<title>INS-Nordkivu</title>
	<meta http-equiv="content-Type" content="text/html;  charset=utf-8"/>
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="icon" type="image/png" href="http://www.ins-nordkivu.org/favicon.png"/>
	<link rel="stylesheet" type="text/css" href="http://www.ins-nordkivu.org/assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="http://www.ins-nordkivu.org/assets/css/main.css">
	<link rel="stylesheet" type="text/css" href="http://www.ins-nordkivu.org/assets/css/bootstrap-theme.css">
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.4.0/dist/leaflet.css"
   integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA=="
   crossorigin=""/>

	<link rel="stylesheet" media="screen and (max-width: 720px)" href="http://www.ins-nordkivu.org/assets/css/small.css" />
    <link rel="stylesheet" media="screen and (min-width: 720px)" href="http://www.ins-nordkivu.org/assets/css/large.css"/>

	<link rel="stylesheet" type="text/css" href="http://www.ins-nordkivu.org/assets/css/font-awesome.min.css">
	

	
	
	
	  
 <body>
	
 	<!-- Fixed navbar -->
	 <div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.php"><img src="http://www.ins-nordkivu.org/assets/img/logo.jpg" alt="Ins"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li><a href="http://www.ins-nordkivu.org/index.php">Accueil</a></li>
					<li class="dropdown">
						<a href="cdcd" class="dropdown-toggle" data-toggle="dropdown">Statistiques<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="http://www.ins-nordkivu.org/generales/statistiques/sgenerales.php"> Statistiques générales</a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/statistiques/seconomiques.php">Statistiques économiques </a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/statistiques/sdemographie.php">Statistiques démographie</a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/statistiques/sautres.php"> Autres statistiques </a></li>

						</ul>
					</li>
						
					
					<li class="dropdown">
						<a href="cdcd" class="dropdown-toggle" data-toggle="dropdown">A propos<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="http://www.ins-nordkivu.org/generales/mission.php"> Notre mission</a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/perspectives.php"> Nos perspectives </a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/realisations.php"> Nos réalisations</a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/potentialites.php"> Nos potentialités </a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/prerogatives.php"> Nos prerogatives </a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/vision.php"> Notre vision à moyen terme </a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/defis.php"> Nos défis majeurs </a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/equipe.php"> Notre équipe </a></li>
							<li><a href="http://www.ins-nordkivu.org/generales/contact.php">Nous contacter</a></li>
						</ul>
					</li>
					<li><a href="http://www.ins-nordkivu.org/generales/publications.php">Publications</a></li>
					<li><a href="http://www.ins-nordkivu.org/generales/enquetes.php">Enquêtes & recensements</a></li>
					<li><a href="http://www.ins-nordkivu.org/generales/indices.php">Les indices de prix</a></li>
					<li class="dropdown">
						<a href="cdcd" class="dropdown-toggle" data-toggle="dropdown">Projet & Activités<b class="caret"></b></a>
						<ul class="dropdown-menu">
						<li><a href="http://www.ins-nordkivu.org/generales/projetsactivites/projets.php">Projets</a></li>
						<li><a href="http://www.ins-nordkivu.org/generales/projetsactivites/ateliers.php">Ateliers</a></li>
						<li><a href="http://www.ins-nordkivu.org/generales/projetsactivites/seminaire.php">Séminaires</a></li>
						<li><a href="http://www.ins-nordkivu.org/generales/projetsactivites/formation.php">Formations</a></li>
						<li><a href="http://www.ins-nordkivu.org/generales/projetsactivites/activitesencours.php">Activités en cours</a></li>
					   </ul>
					</li>
					<li class="active"><a class="btn" href="http://www.ins-nordkivu.org/generales/signin.php">Connexion</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>
		
		
		
 


