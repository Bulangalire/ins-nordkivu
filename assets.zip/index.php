
<?php

               include("libs/db_connected.php");
               include("header.php");
              
               //Connexion à la base des données
                
                $sqlActuelle="SELECT indicateur.id, indicateur.indicateur, indicateur.photo,
                 profilgeneral.annee, profilgeneral.nombre FROM indicateur, profilgeneral 
                WHERE indicateur.id=profilgeneral.indicateur and profilgeneral.annee='2015' ORDER BY profilgeneral.annee";
               
              
                $sqlPasser="SELECT indicateur.indicateur, indicateur.photo,
                profilgeneral.annee, profilgeneral.nombre FROM indicateur, profilgeneral 
                WHERE indicateur.id=profilgeneral.indicateur and profilgeneral.annee='2014' ORDER BY profilgeneral.annee";
                
                $sqlAnteriere="SELECT indicateur.indicateur, indicateur.photo,
                profilgeneral.annee, profilgeneral.nombre FROM indicateur, profilgeneral 
                WHERE indicateur.id=profilgeneral.indicateur and profilgeneral.annee='2013' ORDER BY profilgeneral.annee";

                $resultSetActuel = mysqli_query($con, $sqlActuelle);
                $resultSetAct = mysqli_query($con, $sqlActuelle);
                $totalPopulation= mysqli_fetch_array($resultSetAct);
                $resultSetActuel = mysqli_query($con, $sqlActuelle);
                $resultPasse = mysqli_query($con, $sqlPasser);
                $resultAnteriere = mysqli_query($con, $sqlAnteriere);

                $queryAvenue="SELECT statavanue.annee, (statavanue.homme + statavanue.femme + statavanue.garcon +statavanue.fille) as  total FROM avenue,statavanue WHERE statavanue.avenue= avenue.id GROUP BY avenue.id";
                $resultAvenue = mysqli_query($con, $queryAvenue);
                
               $totalGoma =0;
               while ( $rsAvenue = mysqli_fetch_array($resultAvenue)) {
                $totalGoma = $totalGoma + $rsAvenue['total'];
            }
           
?>

<section class="container-fluid banner">
         
			<div class="ban" id="id-ban">
                <img src="http://www.ins-nordkivu.org/assets/img/bloc/ban.gif" alt="banner du site" />
            </div>
            <div class="inner-banner" id="inner-b">
               
                <h1>Institut National de la Statistique</h1>
                <h3>Direction Provinciale du Nord-Kivu</h3>
                <a href="http://www.ins-nordkivu.org/generales/publications.php" class="btn btn-succes">Plus d'info</a>
            </div>

            <div class="data-banner-device">
                <br>
                <a href="http://www.ins-nordkivu.org/assets/img/publication/inflation2015.png" target="_blank" rel="noopener noreferrer"> <h6> <img src="http://www.ins-nordkivu.org/assets/img/icon/inflation.png"  width="35" height="35"  alt="inflationNK" srcset=""> Inflation en 2015</h6></a>
                <br>
                <a href="http://www.ins-nordkivu.org/generales/publications.php"> <h6> <img src="http://www.ins-nordkivu.org/assets/img/icon/indice.png"  width="35" height="35"  alt="indice" srcset="">   Indeces de prix </h6></a>
            
                <a href="http://www.ins-nordkivu.org/generales/avenue.php" class="btn btn-succes"><h6> <img src="http://www.ins-nordkivu.org/assets/img/icon/population.png"  width="35" height="35"  alt="goma-avenue" srcset="">Goma et ses avenues </h6><?php echo "En 2015, polulation ". number_format($totalGoma,0,',', ' ');?></a>
            
            </div>


            <div class="row feactured">
        
                <div class="inflation-banner">
                    <img class="image-inf" src="http://www.ins-nordkivu.org/assets/img/publication/inflation2015.png" alt="inflation" width="315" height="181" />
                </div>
         
            <div class="actustat-banner" >
                
                <h2>Goma et ses avenues</h2>
                <h3><?php echo "En 2015, polulation ". number_format($totalGoma,0,',', ' ');?></h3>
                <a href="http://www.ins-nordkivu.org/generales/avenue.php" class="btn btn-succes">En savoir plus</a>
           
            </div>

            <div class="price-index-banner">
                
           
              <a href="http://www.ins-nordkivu.org/generales/publications.php"> <img class="image-inf" src="http://www.ins-nordkivu.org/assets/img/icon/indice.png" alt="indece-prix" width="315" height="181" /></a>
           
            </div>
            </div>
</section>

<section class="container">
    <div class="row">
    <article> 



    <?php 
   
 
            while ( $resultatActuel = mysqli_fetch_array($resultSetActuel)) {
            ?>           
        <div class="news-item news-item-portfolio">
				<div class="media">
					<img src="http://www.ins-nordkivu.org/assets/img/publication/profilnk/<?php echo $resultatActuel['photo']; ?>.jpg"  alt="profil-<?php echo $resultatActuel['photo']; ?>"/>
					<span></span>
				</div>
				<div class="copy">
                <h6 class="title" data-title=""><?php 
                mb_internal_encoding('UTF-8');
                echo $resultatActuel['indicateur'] ; ?></h6>
                <h6 class="title" data-title="">En
                <?php echo $resultatActuel['annee']; ?>
                <?php    $rowPass = mysqli_fetch_array($resultPasse);
                         $rowAnteriere = mysqli_fetch_array($resultAnteriere);
                          $tauxPasse=number_format((($rowPass['nombre'] - $rowAnteriere['nombre']) /$rowAnteriere['nombre']) * 100,2,',', ' ');
                          if($resultatActuel['id']==1 || $resultatActuel['id']==2 || $resultatActuel['id']==3 || $resultatActuel['id']==4 || $resultatActuel['id']==5 || $resultatActuel['id']==7) {
                            echo 'T. Croissance '.  $tauxActuel= number_format((($resultatActuel['nombre'] - $rowPass['nombre']) /$rowPass['nombre']) * 100,2,',', ' ')."%";
                            echo  $tauxPasse > $tauxActuel ? '<img src="http://www.ins-nordkivu.org/assets/img/publication/profilnk/fleche_bas.png" height="10" width="10" />' : '<img src="http://www.ins-nordkivu.org/assets/img/publication/profilnk/fleche_haut.png"  height="10" width="10"/>';
                          }
               ?>  
                <br>
                <?php echo  number_format($resultatActuel['nombre'],0,',', ' ');
               
                 
              echo '&nbsp;';   
              if($resultatActuel['id']==2 || $resultatActuel['id']==3 || $resultatActuel['id']==4  ) {
                echo 'soit '. number_format(($resultatActuel['nombre']*100)/$totalPopulation['nombre'],2,',', ' ') ."% de population.";
              }      
          

              ?> 
            </h6>
                
					<span class="desc">
                    <a class="modeless" title="" href="http://www.ins-nordkivu.org/generales/profilgeneral.php?indicateur=<?php echo $resultatActuel['id']; ?>" data-intro=""> En savoir plus
					</a>
					</span>
				</div>
			</div>
            <?php
            }

            mysqli_free_result($resultSetActuel);
            mysqli_free_result($resultPasse);
            mysqli_free_result($resultAnteriere);
       
            ?>
            </article>
    </div>
</section>

 <section class="container-fluid about" id="aboutArea">
     <div class="container">
     <h4 id="about"> Qui sommes-nous </h4>
             <hr class="separator">
         <div class="row">
        
            <article class="col-md-4 col-lg-4 col-xs-12 col-sm-12 quisommes">
                <h4>Notre Mission</h4>
                <p>
                            l’Institut National de la Statistique a 
            pour mission générale de rassembler, analyser et diffuse des informations 
            pour le compte du Gouvernement principalement,
            des informations statistiques nécessaires pour 
            sa politique démographique, 
            économique et sociale. </p>
            <div>
                <a href="http://www.ins-nordkivu.org/generales/mission.php" style="font-size:14px; line-height: 27px;">En savoir plus</a>
            </div>
            </article>
            <article class="col-md-4 col-lg-4 col-xs-12 col-sm-12 quisommes">
                <h4>Réalisations</h4>
                <p>
                Trouvez ici, quelque productions statistiques déjà réalisées par l’INS Nord-Kivu avec l’appui du Gouvernement et des partenaires.
                Enquête Démographique et de Santé, annuaire statistique,
                bulletin annuel des statistiques socioéconomique, ...
                   </p>
                   <div>
                <a href="http://www.ins-nordkivu.org/generales/realisations.php" style="font-size:14px; line-height: 27px;">En savoir plus</a>
            </div>
            </article>
            <article class="col-md-4 col-lg-4 col-xs-12 col-sm-12 quisommes">
                <h4>Publications</h4>
                <p>
                <a href="http://www.ins-nordkivu.org/generales/publications.php#bulletin-2015" style="color:#000; visited:#000; hover:hotpink;">Bulletin annuel des Statistiques sociales Edition 2015, </a>
                
                <a href="http://www.ins-nordkivu.org/generales/publications.php#bulletin-2014" style="color:#000; visited:#000; hover:hotpink;">Bulletin annuel des Statistiques sociales Edition 2014, </a>
                
                <a href="http://www.ins-nordkivu.org/generales/publications.php#bulletin-2013" style="color:#000; visited:#000; hover:hotpink;">Bulletin annuel des Statistiques sociales Edition 2013,</a>
                <a href="http://www.ins-nordkivu.org/generales/publications.php#avenues-2016" style="color:#000; visited:#000; hover:hotpink;">Goma et ses avenues, </a>
                <a href="http://www.ins-nordkivu.org/generales/publications.php#etude-2017" style="color:#000; visited:#000; hover:hotpink;">Étude qualitative sur la consolidation de la paix et la reconstruction en RDC</a> </p>
                <div>
                <a href="http://www.ins-nordkivu.org/generales/publications.php" style="font-size:14px; line-height: 27px;">En savoir plus</a>
            </div>
            </article>

         </div>
     </div>
 </section>



 
 <?php
            include("footer.php");
              ?>
