	<!-- Sidebar -->
    <aside class="col-sm-4 sidebar sidebar-right">

   
   <div class="widget publicationFrame" >
   
        <p><a href="http://www.ins-nordkivu.org/generales/publications.php">Publications</a><br>
        <span class="small text-muted">1. Bulletin annuel des Statistiques sociales</span><br>
        <span class="small text-muted"><a href="http://www.ins-nordkivu.org/generales/avenue.php">2. Goma et ses avenues</a></span><br>
        <span class="small text-muted">3. Étude qualitative sur la consolidation de la paix et la reconstruction en RDC Mars 2017</span><br>
        <span class="small text-muted">4. Étude qualitative sur la consolidation de la paix et la reconstruction en RDC Octobre 2018</span><br>
        <span class="small text-muted">5. Synthese sur de l'Étude qualitative de la consolidation de la paix et la reconstruction RDC</span><br>
        <span class="small text-muted">6. Goma en chiffres 2013</span>
        
        </p>
        <p><a href="http://www.ins-nordkivu.org/generales/centrecalcul.php">Centre de calcul</a><br>
        
        <span class="small text-muted">Un centre moderne de calcule équipé d’un matériel technologique de la dernière génération</span></p>
        <p><a href="http://www.ins-nordkivu.org/generales/equipe.php">Equipe INS nord-kivu</a><br><span class="small text-muted">L’INS dispose d’un personnel multisectoriel actif et spécialisé dans différents domaines (statistique, démographie, économie, informatique, gestion, finance etc.) ;</span></p>
        <p><a href="http://www.ins-nordkivu.org/generales/contact.php">Retouvez-nous</a><br><span class="small text-muted">134 bis, Av. du Port, Quartier Les Volcans, Commune de Goma, Voir Ancien Auditorat Militaire, avec la Division Provinciale du Plan, Ville de Goma/RDC </span></p>
        <p><a href="http://www.ins-nordkivu.org/generales/centrecalcul.php">Galerie de photos</a><br><img src="http://www.ins-nordkivu.org/assets/img/publication/entree.jpg" alt="" class="img-rounded pull-center" width="300" ></p>
    </div>

</aside>
<!-- /Sidebar -->